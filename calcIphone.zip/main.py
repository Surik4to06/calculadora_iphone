from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtWidgets import QWidget
from PyQt5.uic import loadUi
from logger import LogManagement


class calculadora(QMainWindow):
    op = None
    Num1 = 0
    Num2 = 0
    def __init__(self):
        super().__init__()
        loadUi( 'untitled.ui', self )




        self.adicao: QPushButton
        self.subtracao: QPushButton
        self.multiplicacao: QPushButton
        self.divisao: QPushButton
        self.porcentagem: QPushButton
        self.limpar: QPushButton
        self.inverter_valores: QPushButton
        self.igual: QPushButton
        self.virgula: QPushButton
        self.btn0: QPushButton
        self.btn1: QPushButton
        self.btn2: QPushButton
        self.btn3: QPushButton
        self.btn4: QPushButton
        self.btn5: QPushButton
        self.btn6: QPushButton
        self.btn7: QPushButton
        self.btn8: QPushButton
        self.btn9: QPushButton
        self.tela: QLabel
        
        
        
        self.porcentagem.clicked.connect(lambda: self.operacao(self.porcentagem))
        self.divisao.clicked.connect(lambda:self.operacao(self.divisao))
        self.multiplicacao.clicked.connect(lambda: self.operacao(self.multiplicacao))
        # self.subtracao.clicked.connect(lambda: self.operacao(self.subtracao))
        self.adicao.clicked.connect(lambda: self.operacao(self.adicao))
        self.btn0.clicked.connect(lambda: self.setLabel(0))
        self.btn1.clicked.connect(lambda: self.setLabel(1))
        self.btn2.clicked.connect(lambda: self.setLabel(2))
        self.btn3.clicked.connect(lambda: self.setLabel(3))
        self.btn4.clicked.connect(lambda: self.setLabel(4))
        self.btn5.clicked.connect(lambda: self.setLabel(5))
        self.btn6.clicked.connect(lambda: self.setLabel(6))
        self.btn7.clicked.connect(lambda: self.setLabel(7))
        self.btn8.clicked.connect(lambda: self.setLabel(8))
        self.btn9.clicked.connect(lambda: self.setLabel(9))
        self.igual.clicked.connect(self.resultado)


    


    def adicao(self, valor1, valor2):
        return valor1 + valor2

    def subtracao(self, valor1, valor2):
        return valor1 - valor2
    
    def multiplicacao(self, valor1, valor2):
        return valor1 * valor2


    def divisao(self, valor1, valor2):
        return valor1/valor2

    def porcentagem(self, valor1):
        resultado = valor1/100*2
        return resultado
    
    def operacao(self, operacao):
        self.op = operacao
        self.Num1 = int(self.tela.text())
        self.Num2 = 0
        self.tela.setNum(0)


    def setLabel(self, valor):
        valor1 = str(valor)
        self.tela.setText(valor1)
        
    def resultado(self):
        if self.op:
            self.num2 = int(self.tela.setNum())
            return self.op

    def mostrarResultado(self):
        if self.op:
            if self.Num2:
                self.Num1 = int(self.tela.text())
            else:
                self.Num2 = int(self.tela.text())
        resutado = self.op()
        self.tela.setText(str(resutado))





if __name__ == '__main__':
    app = QApplication([])
    janela = calculadora()
    janela.show()
    app.exec_()
    